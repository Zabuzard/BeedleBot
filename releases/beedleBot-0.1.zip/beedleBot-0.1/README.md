# BeedleBot
BeedleBot is tool for the MMORPG Freewar which automizes the trade and the corresponding sale at the central traders depot. It comes with an integrated web user interface.

The available documentation can be found in [our wiki](https://github.com/ZabuzaW/BeedleBot/wiki).
